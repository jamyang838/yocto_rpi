#include <iostream>
#include <cstdlib>

int main(){    
    std::cout << "Hellow 900772 - Makefile ok!" << std::endl;
    return EXIT_SUCCESS;
}